self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d7d265aa1ec31c6b8401708da5969d6b",
    "url": "https://bob-musicplayer.github.io/front-bob/index.html"
  },
  {
    "revision": "c98a5413bfaaabeac576",
    "url": "https://bob-musicplayer.github.io/front-bob/static/css/main.f6296f07.chunk.css"
  },
  {
    "revision": "168f4418e21472f42289",
    "url": "https://bob-musicplayer.github.io/front-bob/static/js/2.92c8a8ff.chunk.js"
  },
  {
    "revision": "c98a5413bfaaabeac576",
    "url": "https://bob-musicplayer.github.io/front-bob/static/js/main.c017dc56.chunk.js"
  },
  {
    "revision": "74ce35477705da0371eb",
    "url": "https://bob-musicplayer.github.io/front-bob/static/js/runtime~main.5dc0a981.js"
  }
]);